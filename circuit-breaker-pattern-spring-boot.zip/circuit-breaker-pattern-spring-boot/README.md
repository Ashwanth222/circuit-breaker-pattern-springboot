# circuit-breaker-pattern-spring-boot

Medium Article: https://medium.com/@buingoctruong1995/circuit-breaker-pattern-in-spring-boot-d2d258b75042
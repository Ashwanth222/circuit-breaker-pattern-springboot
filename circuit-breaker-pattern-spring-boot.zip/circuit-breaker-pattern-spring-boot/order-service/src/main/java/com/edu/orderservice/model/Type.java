package com.edu.orderservice.model;

public interface Type {
}
